/*
Tastaturemuliation funktioniert.
Neopixel LED funktioniert.
Plunger funktioniert.
Accellerator funktioniert.
SHIFT und CTRL Tasten funktionieren nun auch.
USB sent optimiert um die USB Schnittstelle nicht unnötig zu belasten.
Kommentare verbessern lassen.
USB periodisch aktualisisern um verlorene events zu kompensieren.
Tilt impuls an den PC verlängern auf 20ms.
Verhalaten von Numpad 2 5 und 8 korrigiert.
TODO:
Test mit VPX

================================================================================
  Pinbelegung ESP32-S3 Flipper Controller
================================================================================

  Funktion                 | Pin-Name im Code | GPIO | Logik | Emulierte Taste
  -------------------------|------------------|------|-------|-------------------------
  ** I2C (für MPU6050 Gyro) **
  I2C Data                 | I2C_SDA          | 8    | -     | (Joystick X/Y-Achse)
  I2C Clock                | I2C_SCL          | 9    | -     | (Joystick X/Y-Achse)

  ** Flipper & Magna-Save **
  Flipper Rechts           | PIN_FR           | 1    | NC    | Rechte Shift-Taste
  Flipper Links            | PIN_FL           | 2    | NC    | Linke Shift-Taste
  Magna-Save Rechts        | PIN_MR           | 4    | NO    | Rechte Strg-Taste
  Magna-Save Links         | PIN_ML           | 5    | NO    | Linke Strg-Taste

  ** Spiel- & System-Tasten **
  Credit / Münzeinwurf     | PIN_CR           | 3    | NO    | '5'
  TILT                     | PIN_TILT         | 6    | NO    | 't'
  Start / Eingabe (Return) | PIN_RET          | 14   | NO    | Enter / Return
  Escape                   | PIN_ESC          | 13   | NO    | Escape

  ** Menü-Navigation **
  Pfeil Hoch               | PIN_AU           | 7    | NO    | Pfeil Hoch
  Pfeil Runter             | PIN_AD           | 10   | NO    | Pfeil Runter
  Pfeil Links              | PIN_AL           | 11   | NO    | Pfeil Links
  Pfeil Rechts             | PIN_AR           | 12   | NO    | Pfeil Rechts

  ** Numpad-Tasten **
  Numpad 2                 | PIN_NUM2         | 16   | NO    | Numpad 2
  Numpad 5                 | PIN_NUM5         | 17   | NO    | Numpad 5
  Numpad 8                 | PIN_NUM8         | 18   | NO    | Numpad 8

  ** Plunger (Analog & Digital) **
  Plunger Encoder A        | ROT1             | 42   | -     | (Joystick Z-Achse)
  Plunger Encoder B        | ROT2             | 41   | -     | (Joystick Z-Achse)
  Plunger Button (Launch)  | PLU              | 21   | NO    | Pfeil Hoch

  ** Sonstiges **
  Onboard NeoPixel LED     | NEOPIXEL_PIN     | 48   | -     | (Status-LED)

================================================================================
*/
#include <Arduino.h>
#include <Wire.h>
#include <Bounce2.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include "USB.h"
#include "USBHIDKeyboard.h"
#include "USBHIDGamepad.h"
#include "USBHID.h" // WICHTIG: Diesen Header für den 'KeyCode' Typ einbinden
#include <Adafruit_NeoPixel.h>

// Manuelle Definitionen für Keypad-Tasten.
// Die Standard-Definitionen in vielen Bibliotheken sind für ein US-Layout.
// Diese hier sind die korrekten USB HID Scancodes, die layout-unabhängig funktionieren sollten.
#define KEY_KP_2 0x5A // Numpad 2
#define KEY_KP_5 0x5D // Numpad 5
#define KEY_KP_8 0x60 // Numpad 8

// Manuelle Definition der HID Modifier-Bitmasken für den KeyReport
// Dies ist der robustere Weg, um Modifikatortasten (SHIFT, CTRL, etc.) zu steuern.
#define KEY_MOD_LCTRL  0x01
#define KEY_MOD_LSHIFT 0x02
#define KEY_MOD_LALT   0x04
#define KEY_MOD_LGUI   0x08
#define KEY_MOD_RCTRL  0x10
#define KEY_MOD_RSHIFT 0x20
#define KEY_MOD_RALT   0x40
#define KEY_MOD_RGUI   0x80

/*
  BIBLIOTHEKEN (über Bibliotheksverwalter installieren):
  1. Adafruit MPU6050
  2. Adafruit Unified Sensor
  3. Bounce2
*/

// USB HID Objekte initialisieren
USBHIDKeyboard Keyboard;
USBHIDGamepad Gamepad;

// HID Report-Struktur, um den Zustand aller Modifikator-Tasten zu halten
KeyReport keyReport;

// NeoPixel Objekt für die Onboard-LED
Adafruit_NeoPixel statusPixel(1, 48, NEO_GRB + NEO_KHZ800);

// PIN DEFINITIONEN FÜR ESP32-S3 (Bitte an Ihr spezifisches Board anpassen!)
// I2C Pins (Standard für viele S3 Boards, aber prüfbar)
#define I2C_SDA 8
#define I2C_SCL 9

// Button Pins (Nutzung von GPIOs, die sicher als Input Pullup gehen)
#define PIN_FR    1   // Flipper rechts
#define PIN_FL    2   // Flipper links
#define PIN_CR    3   // Credits
#define PIN_MR    4   // Magna Save rechts
#define PIN_ML    5   // Magna Save links
#define PIN_TILT  6   // TILT
#define PIN_AU    7   // Pfeil HOCH
#define PIN_AD    10  // Pfeil RUNTER
#define PIN_AL    11  // Pfeil LINKS
#define PIN_AR    12  // Pfeil RECHTS
#define PIN_ESC   13  // Pin Escape
#define PIN_RET   14  // Pin Return/Eingabe
// #define LED   15  // Alte Definition für externe LED, wird durch NeoPixel ersetzt
#define PIN_NUM2  16  // Pin Nummernblock 2
#define PIN_NUM5  17  // Pin Nummernblock 5
#define PIN_NUM8  18  // Pin Nummernblock 8

// Encoder & Plunger
#define ROT1  42  // Drehencoder A - WICHTIG: Nicht GPIO 19/20 verwenden, da diese für USB reserviert sind!
#define ROT2  41  // Drehencoder B - WICHTIG: Nicht GPIO 19/20 verwenden, da diese für USB reserviert sind!
#define PLU   21  // Plunger-Button (Pin mit internem Pull-Up)

// Konstantendeklarationen
const int ButtonDebounce = 5;      // Entprellzeit (ms)
const int TILT_PULSE_DURATION_MS = 20; // Mindestdauer für den TILT-Tastendruck
const int NUM5_PULSE_DURATION_MS = 20; // Dauer für den Numpad-5-Tastendruck

const int MaxPosition = 300;       // Maximale logische Encoder-Position
const int StartPosition = 240;     // Startposition für Plunger-Logik
const int ReleasePosition = 50;    // Release-Schwelle

// Joystick Wertebereich ESP32 HID Gamepad ist typisch -127 bis 127 (int8_t)
const int JoyMin = -127;
const int JoyMax = 127;
// MPU Sensitivität anpassen für neuen Bereich
const int AccelleromerterSensivity = 8; 

const int TiltFilterTime = 1000;
const unsigned long ShortPlungerPressTime = 300;
const unsigned long LongPlungerPressTime = 1000;
const int PlungerMaxHoldTime = 1000;
const unsigned long PlungerCancelAnimationTime = 500;

// Wiederholende Tasten Konstanten
const int REPEAT_INITIAL_DELAY_MS = 300;
const int REPEAT_PRESS_DURATION_MS = 30;
const int REPEAT_RELEASE_DURATION_MS = 30;

// Struktur zur Verwaltung von Tasten mit Wiederholungsfunktion
// Die Struktur `RepeatingKey` wird nicht mehr verwendet, die Logik ist jetzt direkt in `handleButtons` implementiert.
// struct RepeatingKey {
//   ...
// };

// Objekte
Adafruit_MPU6050 mpu;

// Button Objekte
Bounce buttonFR = Bounce();
Bounce buttonFL = Bounce();
Bounce buttonMR = Bounce();
Bounce buttonML = Bounce();
Bounce buttonCR = Bounce();
Bounce buttonTILT = Bounce();
Bounce buttonAU = Bounce();
Bounce buttonAD = Bounce();
Bounce buttonAL = Bounce();
Bounce buttonAR = Bounce();
Bounce buttonESC = Bounce();
Bounce buttonRET = Bounce();
Bounce buttonPLU = Bounce();
Bounce buttonNUM2 = Bounce();
Bounce buttonNUM5 = Bounce();
Bounce buttonNUM8 = Bounce();

// Variablen für manuelles Encoder-Polling
// Für robuste Quadratur-Dekodierung
volatile int8_t encoder_last_state = 0;
// Lookup-Tabelle für die Zustandsübergänge des Encoders.
// Index: (last_state << 2) | current_state
// Werte: 0 = keine Änderung, 1 = CW, -1 = CCW
const int8_t encoder_states[] = {0,-1,1,0,1,0,0,-1,-1,0,0,1,0,1,-1,0};



// Variablen
unsigned long TiltMillis;               // Zeitstempel, um TILT-Eingaben zu entprellen/filtern
int Position = 0;                       // Aktuelle logische Position des Plunger-Encoders (0 bis MaxPosition)
int PositionOld = 0;                    // Letzte bekannte Position des Encoders, um Änderungen zu erkennen
bool KnopfGedreht = false;              // Merker, ob der Plunger (Encoder) bewegt wurde und die Logik aktiv ist
int PositionOut;                        // Gemappter Encoder-Wert für die Joystick Z-Achse (-127 bis 127)
uint8_t lastModifiers = 0;              // Zustand der Modifier-Tasten des letzten Reports, um unnötige Sends zu vermeiden
unsigned long PlungerPressStartTime = 0;  // Zeitstempel, wann der Plunger-Knopf gedrückt wurde
bool PlungerPressed = false;            // Aktueller Zustand des Plunger-Knopfes (gedrückt/losgelassen) 
int tiltState = 0;                      // Zustand für die nicht-blockierende TILT-Logik (0=idle, 1=pressed, 2=waiting_release)
float xbaseline, ybaseline;             // Nullpunkt-Offset für den Beschleunigungssensor nach der Kalibrierung
int num2State = 0;                      // Zustand für die nicht-blockierende Numpad-2-Logik
unsigned long num2_press_timer = 0;     // Timer für die Dauer des Numpad-2-Tastendrucks
int num5State = 0;                      // Zustand für die nicht-blockierende Numpad-5-Logik
unsigned long num5_press_timer = 0;     // Timer für die Dauer des Numpad-5-Tastendrucks
int num8State = 0;                      // Zustand für die nicht-blockierende Numpad-8-Logik
unsigned long num8_press_timer = 0;     // Timer für die Dauer des Numpad-8-Tastendrucks
volatile bool tiltInterruptFired = false; // Flag, das von der TILT-Interrupt-Routine gesetzt wird
bool tiltKeyPressed = false;            // Zustand für die TILT-Taste, um verwaiste 'release'-Befehle zu verhindern
sensors_event_t accel, gyro, temp;      // Structs zum Speichern der MPU6050-Sensordaten
int x, y;                               // Aufbereitete Werte für die Joystick X- und Y-Achse (Nudge/Tilt)
int z;                                  // Aufbereiteter Wert für die Joystick Z-Achse (Plunger)
int Step = 0;                           // Aktueller Schritt in der Plunger-Zustandsmaschine (State Machine)
unsigned long step_timer = 0;           // Universeller Timer für nicht-blockierende Delays in der State Machine
unsigned long tilt_press_timer = 0;     // Timer für die Dauer des TILT-Tastendrucks
unsigned long case45_entry_time = 0;    // Spezieller Timer für den Start der "Cancel"-Animation (Step 45)

// Timer für die Begrenzung der Gamepad-Sendefrequenz
unsigned long last_gamepad_send_time = 0;
const int GAMEPAD_SEND_INTERVAL_MS = 10; // Sende alle 10ms (100Hz). Ein guter Kompromiss aus Latenz und USB-Last.

void readEncoder() {
    // Robuste Quadratur-Dekodierung (korrigierte Version)
    
    // 1. Lese den aktuellen Zustand der beiden Pins (ergibt einen Wert von 0-3)
    int8_t current_state = (digitalRead(ROT1) << 1) | digitalRead(ROT2);

    // 2. Kombiniere den alten und neuen Zustand, um einen Index für die Lookup-Tabelle zu erstellen
    int8_t lookup_index = (encoder_last_state << 2) | current_state;

    // 3. Inkrementiere/dekrementiere die Position basierend auf dem Wert aus der Tabelle
    Position += encoder_states[lookup_index];

    // 4. Speichere den aktuellen Zustand für den nächsten Durchlauf
    encoder_last_state = current_state;
}

// Interrupt Service Routine (ISR) für den TILT-Pin.
// Diese Funktion wird SOFORT aufgerufen, wenn der Pin auf LOW wechselt.
// IRAM_ATTR sorgt dafür, dass der Code im schnellen IRAM liegt.
void IRAM_ATTR onTilt() {
    tiltInterruptFired = true;
}

void setup() {
    // USB Initialisierung für ESP32-S3
    // MUSS vor Serial.begin() erfolgen, wenn USB-CDC aktiv ist!
    USB.begin();
    Keyboard.begin();
    Gamepad.begin();
    
    // Serial.begin(115200); // Serielle Ausgaben für den Test komplett deaktivieren, um USB-Konflikte zu vermeiden

    // I2C Initialisierung
    Wire.begin(I2C_SDA, I2C_SCL);

    // MPU6050
    if (!mpu.begin()) {
        // Serial.println("MPU6050 nicht gefunden! Check wiring.");
        // while (1) delay(10); // Endlosschleife entfernt, damit Controller trotzdem bootet
    } else {
        // Serial.println("MPU6050 gefunden");
        mpu.setAccelerometerRange(MPU6050_RANGE_2_G);
        mpu.setFilterBandwidth(MPU6050_BAND_94_HZ);
        
        // Kalibrierung
        for (int i = 0; i < 100; i++) {
            mpu.getEvent(&accel, &gyro, &temp);
            xbaseline += accel.acceleration.x;
            ybaseline += accel.acceleration.y;
            delay(5); // Kurze Pause zwischen den Messungen
            delay(0); // Watchdog füttern, um einen Boot-Loop zu verhindern
        }
        xbaseline /= 100;
        ybaseline /= 100;
    }

    // Pins Attach
    buttonFL.attach(PIN_FL, INPUT_PULLUP); buttonFL.interval(ButtonDebounce);
    buttonFR.attach(PIN_FR, INPUT_PULLUP); buttonFR.interval(ButtonDebounce);
    buttonML.attach(PIN_ML, INPUT_PULLUP); buttonML.interval(ButtonDebounce);
    buttonMR.attach(PIN_MR, INPUT_PULLUP); buttonMR.interval(ButtonDebounce);    
    buttonCR.attach(PIN_CR, INPUT_PULLUP); buttonCR.interval(ButtonDebounce);
    buttonAU.attach(PIN_AU, INPUT_PULLUP); buttonAU.interval(ButtonDebounce);
    buttonAD.attach(PIN_AD, INPUT_PULLUP); buttonAD.interval(ButtonDebounce);
    buttonAL.attach(PIN_AL, INPUT_PULLUP); buttonAL.interval(ButtonDebounce);
    buttonAR.attach(PIN_AR, INPUT_PULLUP); buttonAR.interval(ButtonDebounce);
    buttonESC.attach(PIN_ESC, INPUT_PULLUP); buttonESC.interval(ButtonDebounce);
    buttonRET.attach(PIN_RET, INPUT_PULLUP); buttonRET.interval(ButtonDebounce);
    buttonPLU.attach(PLU, INPUT_PULLUP); buttonPLU.interval(ButtonDebounce);
    buttonNUM2.attach(PIN_NUM2, INPUT_PULLUP); buttonNUM2.interval(ButtonDebounce);
    buttonNUM5.attach(PIN_NUM5, INPUT_PULLUP); buttonNUM5.interval(ButtonDebounce);
    buttonNUM8.attach(PIN_NUM8, INPUT_PULLUP); buttonNUM8.interval(ButtonDebounce);

    // TILT-Pin separat als Interrupt konfigurieren, um auch kürzeste Impulse zu fangen.
    pinMode(PIN_TILT, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(PIN_TILT), onTilt, FALLING);

    // Onboard NeoPixel LED initialisieren und auf Rot setzen
    statusPixel.begin(); // Nur initialisieren, nicht einschalten
    
    // Encoder Pins für manuelles Polling konfigurieren
    pinMode(ROT1, INPUT_PULLUP);
    pinMode(ROT2, INPUT_PULLUP);
    // Initialen Zustand des Encoders lesen
    encoder_last_state = (digitalRead(ROT1) << 1) | digitalRead(ROT2);

    TiltMillis = millis() + TiltFilterTime;
}

void PlungerAktualisieren() {
    // Der 'Position'-Wert wird jetzt durch readEncoder() aktualisiert.
    
    // Begrenzung logisch
    if (Position > MaxPosition) {
        Position = MaxPosition;
    } else if (Position < 0) {
        Position = 0;
    }

    // Mapping: 0 bis MaxPosition (300) -> HID Bereich -127 bis 127
    // Für Z-Achse in Visual Pinball
    PositionOut = map(Position, 0, MaxPosition, JoyMin, JoyMax);
    z = PositionOut; // Z-Achsenwert in globaler Variable speichern
}

void handleButtons() {
    // Button Updates
    buttonFL.update(); buttonFR.update(); buttonML.update(); buttonMR.update();
    buttonCR.update(); buttonAU.update(); buttonAD.update();
    buttonAL.update(); buttonAR.update(); buttonESC.update(); buttonRET.update();
    buttonPLU.update(); buttonNUM2.update(); buttonNUM5.update(); buttonNUM8.update();

    // --- Logik für Tasten (Identisch zum Teensy Code, angepasst für ESP32 Libs) ---
    
    // Shift Tasten (Flipper) - Verwendung des KeyReports für zuverlässige Funktion
    // Diese Tasten sind "Normally Closed" (NC), daher ist die Logik umgekehrt: rose() = gedrückt, fell() = losgelassen.
    if (buttonFL.rose())  keyReport.modifiers |= KEY_MOD_LSHIFT;  // Taste gedrückt (Kontakt öffnet -> LOW zu HIGH)
    if (buttonFL.fell())  keyReport.modifiers &= ~KEY_MOD_LSHIFT; // Taste losgelassen (Kontakt schließt -> HIGH zu LOW)
    
    if (buttonFR.rose())  keyReport.modifiers |= KEY_MOD_RSHIFT;  // Taste gedrückt
    if (buttonFR.fell())  keyReport.modifiers &= ~KEY_MOD_RSHIFT; // Taste losgelassen

    // Magna Save (STRG) - Verwendung des KeyReports für zuverlässige Funktion
    if (buttonML.fell())  keyReport.modifiers |= KEY_MOD_LCTRL;
    if (buttonML.rose())  keyReport.modifiers &= ~KEY_MOD_LCTRL;

    if (buttonMR.fell())  keyReport.modifiers |= KEY_MOD_RCTRL;
    if (buttonMR.rose())  keyReport.modifiers &= ~KEY_MOD_RCTRL;

    // Pfeiltasten
    if (buttonAU.fell())  Keyboard.press(KEY_UP_ARROW);
    if (buttonAU.rose())  Keyboard.release(KEY_UP_ARROW);
    
    if (buttonAD.fell()) Keyboard.press(KEY_DOWN_ARROW);
    if (buttonAD.rose())  Keyboard.release(KEY_DOWN_ARROW);

    if (buttonAL.fell()) Keyboard.press(KEY_LEFT_ARROW);
    if (buttonAL.rose())  Keyboard.release(KEY_LEFT_ARROW);

    if (buttonAR.fell()) Keyboard.press(KEY_RIGHT_ARROW);
    if (buttonAR.rose())  Keyboard.release(KEY_RIGHT_ARROW);

    // System Tasten
    if (buttonESC.fell()) Keyboard.press(KEY_ESC);
    if (buttonESC.rose())  Keyboard.release(KEY_ESC);

    if (buttonRET.fell()) Keyboard.press(KEY_RETURN);
    if (buttonRET.rose())  Keyboard.release(KEY_RETURN);

    // Coin (sendet das Zeichen '5')
    // Sende nur einen einzigen Tastendruck, wenn der Knopf gedrückt wird.
    // Keyboard.write() sendet ein press() gefolgt von einem release() und verhindert so die Wiederholung durch das OS.
    if (buttonCR.fell()) {
        Keyboard.write('5');
    }

    // Numpad 2: Nicht-blockierende Impuls-Logik mit Wiederholung
    switch (num2State) {
        case 0: // IDLE
            if (buttonNUM2.fell()) {
                Keyboard.pressRaw(KEY_KP_2);
                num2_press_timer = millis();
                num2State = 1; // Ersten Impuls senden
            }
            break;
        case 1: // FIRST_PULSE_RELEASE: Warte, um den ersten Impuls zu beenden
            if (millis() - num2_press_timer >= REPEAT_RELEASE_DURATION_MS) {
                Keyboard.releaseRaw(KEY_KP_2);
                num2_press_timer = millis();
                num2State = 2; // Gehe in die Wartephase für die Wiederholung
            }
            break;
        case 2: // WAITING_FOR_REPEAT: Warte auf Loslassen oder Start der Wiederholung
            if (buttonNUM2.rose()) {
                num2State = 0;
            } else if (millis() - num2_press_timer >= REPEAT_INITIAL_DELAY_MS) {
                num2_press_timer = millis();
                num2State = 3; // Starte die Wiederholungs-Sequenz
            }
            break;
        case 3: // REPEATING_PRESS: Sende einen Wiederholungs-Impuls
            if (buttonNUM2.rose()) { // Prüfe auch hier auf Loslassen
                num2State = 0;
            } else {
                Keyboard.pressRaw(KEY_KP_2);
                num2_press_timer = millis();
                num2State = 4;
            }
            break;
        case 4: // REPEATING_RELEASE: Beende den Wiederholungs-Impuls
            if (buttonNUM2.rose()) { // Prüfe auch hier auf Loslassen
                Keyboard.releaseRaw(KEY_KP_2); // Sicherstellen, dass die Taste losgelassen wird
                num2State = 0;
            } else if (millis() - num2_press_timer >= REPEAT_RELEASE_DURATION_MS) {
                Keyboard.releaseRaw(KEY_KP_2);
                num2_press_timer = millis();
                num2State = 3; // Zurück zum nächsten Wiederholungs-Druck (nach kurzer Pause)
            }
            break;
    }

    // Numpad 5: Nicht-blockierende Impuls-Logik für einen einmaligen, sauberen Tastendruck.
    // Wir verwenden pressRaw() und releaseRaw(), um das Layout-Problem zu umgehen.
    switch (num5State) {
        case 0: // IDLE: Warte auf Tastendruck
            if (buttonNUM5.fell()) {
                Keyboard.pressRaw(KEY_KP_5);
                num5_press_timer = millis(); // Timer starten
                num5State = 1; // Zum nächsten Zustand wechseln
            }
            break;
        case 1: // PRESSED: Warte, bis die Impulsdauer abgelaufen ist
            if (millis() - num5_press_timer >= NUM5_PULSE_DURATION_MS) {
                Keyboard.releaseRaw(KEY_KP_5);
                num5State = 2; // Gehe in einen Wartezustand, bis die Taste losgelassen wird
            }
            break;
        case 2: // WAITING_RELEASE: Tue nichts, bis die Taste physisch losgelassen wurde
            if (buttonNUM5.rose()) {
                num5State = 0; // Bereit für den nächsten Druck
            }
            break;
    }

    // Numpad 8: Nicht-blockierende Impuls-Logik mit Wiederholung
    switch (num8State) {
        case 0: // IDLE
            if (buttonNUM8.fell()) {
                Keyboard.pressRaw(KEY_KP_8);
                num8_press_timer = millis();
                num8State = 1; // Ersten Impuls senden
            }
            break;
        case 1: // FIRST_PULSE_RELEASE: Warte, um den ersten Impuls zu beenden
            if (millis() - num8_press_timer >= REPEAT_RELEASE_DURATION_MS) {
                Keyboard.releaseRaw(KEY_KP_8);
                num8_press_timer = millis();
                num8State = 2; // Gehe in die Wartephase für die Wiederholung
            }
            break;
        case 2: // WAITING_FOR_REPEAT: Warte auf Loslassen oder Start der Wiederholung
            if (buttonNUM8.rose()) {
                num8State = 0;
            } else if (millis() - num8_press_timer >= REPEAT_INITIAL_DELAY_MS) {
                num8_press_timer = millis();
                num8State = 3; // Starte die Wiederholungs-Sequenz
            }
            break;
        case 3: // REPEATING_PRESS: Sende einen Wiederholungs-Impuls
            if (buttonNUM8.rose()) { // Prüfe auch hier auf Loslassen
                num8State = 0;
            } else {
                Keyboard.pressRaw(KEY_KP_8);
                num8_press_timer = millis();
                num8State = 4;
            }
            break;
        case 4: // REPEATING_RELEASE: Beende den Wiederholungs-Impuls
            if (buttonNUM8.rose()) { // Prüfe auch hier auf Loslassen
                Keyboard.releaseRaw(KEY_KP_8); // Sicherstellen, dass die Taste losgelassen wird
                num8State = 0;
            } else if (millis() - num8_press_timer >= REPEAT_RELEASE_DURATION_MS) {
                Keyboard.releaseRaw(KEY_KP_8);
                num8_press_timer = millis();
                num8State = 3; // Zurück zum nächsten Wiederholungs-Druck (nach kurzer Pause)
            }
            break;
    }

    // Der Keyboard-Report für die Modifier-Tasten wird jetzt zusammen mit den Gamepad-Daten
    // in einem festen Intervall in der Haupt-loop() gesendet, um die Robustheit zu erhöhen.
    // Dadurch wird verhindert, dass ein "Loslassen"-Befehl verloren geht und die Taste "hängen" bleibt.
    // Wir prüfen hier nur, ob sich etwas geändert hat, um den Report zu senden.
}

void loop() {
    // Encoder durch Polling auslesen
    readEncoder();

    // --- Nicht-blockierende TILT-Logik (basierend auf Interrupt) ---
    switch (tiltState) {
        case 0: // IDLE: Warte auf einen TILT-Impuls
            if (tiltInterruptFired) {
                tiltInterruptFired = false; // Flag zurücksetzen
                // Prüfe, ob die Filterzeit abgelaufen ist, bevor ein neuer TILT ausgelöst wird.
                if (millis() > TiltMillis) {
                    Keyboard.press('t');
                    tilt_press_timer = millis(); // Timer für die Impulsdauer starten
                    tiltState = 1; // Gehe zum nächsten Zustand
                }
            }
            break;

        case 1: // PRESSED: Warte, bis die Impulsdauer (20ms) abgelaufen ist.
            if (millis() - tilt_press_timer >= TILT_PULSE_DURATION_MS) {
                Keyboard.release('t');
                TiltMillis = millis() + TiltFilterTime; // Sperrzeit für den nächsten TILT starten
                tiltState = 0; // Zurück in den Ruhezustand
            }
            break;

        default:
            tiltState = 0; // Fange ungültige Zustände ab
            break;
    }

    mpu.getEvent(&accel, &gyro, &temp);

    // MPU Mapping: Beschleunigung auf Joystick X/Y
    // Teensy 0-1023 -> ESP32 -127 bis 127
    int x_raw = map((long)((accel.acceleration.x - xbaseline) * 100), 
                    -AccelleromerterSensivity * 100, 
                    AccelleromerterSensivity * 100, 
                    JoyMin, JoyMax);
                    
    int y_raw = map((long)((accel.acceleration.y - ybaseline) * 100), 
                    -AccelleromerterSensivity * 100, 
                    AccelleromerterSensivity * 100, 
                    JoyMax, JoyMin); // Invertiert wie im Original

    // Constrain um Überlauf zu verhindern
    x = constrain(x_raw, JoyMin, JoyMax);
    y = constrain(y_raw, JoyMin, JoyMax);

    // Sende Gamepad- und Keyboard-Modifier-Daten in einem festen Intervall.
    // Dies stellt sicher, dass der Host regelmäßig den korrekten Zustand erhält,
    // selbst wenn ein vorheriges Paket verloren gegangen ist.
    if (millis() - last_gamepad_send_time >= GAMEPAD_SEND_INTERVAL_MS) {
        Gamepad.send(x, y, z, 0, 0, 0, 0, 0); // x, y, z, rz, rx, ry, hat, buttons
        last_gamepad_send_time = millis();
        if (keyReport.modifiers != lastModifiers) {
            Keyboard.sendReport(&keyReport);
            lastModifiers = keyReport.modifiers;
        }
    }

    // Tasten-Logik ausführen
    handleButtons();

    // --- Plunger Logik & State Machine ---
    // Position wird bereits am Anfang der loop() durch readEncoder() aktualisiert.
    if (Position > MaxPosition) { Position = MaxPosition; }
    else if (Position < 0) { Position = 0; }

    if (buttonPLU.fell()) {
        PlungerPressed = true;
        PlungerPressStartTime = millis();
    }
    if (buttonPLU.rose()) {
        PlungerPressed = false;
    }

    switch (Step) {
        // ====================================================================================
        // Plunger State Machine
        // ====================================================================================
        case 0: // IDLE / Grundzustand: Warten auf eine Aktion.
            if ((Position >= 1) && !KnopfGedreht) { // EncoderMin hier vereinfacht auf 1
                Position = StartPosition;
                Position = StartPosition;
                PlungerAktualisieren();
                KnopfGedreht = true; // Merken, dass die Encoder-Logik jetzt aktiv ist.
            }
            if (PlungerPressed) Step = 20;  // Wenn der Knopf gedrückt wird -> Gehe zu Knopf-Logik
            if (KnopfGedreht) Step = 40;     // Wenn der Encoder bewegt wurde -> Gehe zu Encoder-Logik
            break;

        // --- Zweig 1: Digitale Plunger-Aktion (Knopf gedrückt ohne Encoder-Bewegung) ---
        case 20: // Knopf wurde gedrückt. Sende "Pfeil Hoch" für den digitalen Abschuss.
            Keyboard.press(KEY_UP_ARROW); // Launch Ball
            if (!PlungerPressed) {
                // Knopf wurde bereits wieder losgelassen. Unterscheide kurz vs. lang.
                if (millis() - PlungerPressStartTime < ShortPlungerPressTime) Step = 21;
                else Step = 22;
            }
            break;

        case 21: // Kurzer Knopfdruck erkannt. Simuliere einen vollen analogen Plunger-Auszug.
            z = JoyMax; // Setze Z-Achse auf Maximum.
            step_timer = millis();
            Step = 211; // Gehe zum Warte-Zustand.
            break;

        case 211: // Warte eine definierte Zeit, bevor der simulierte Plunger zurückschnellt.
            if (millis() - step_timer >= PlungerMaxHoldTime) {
                z = JoyMin; // Setze Z-Achse zurück auf Minimum.
                Keyboard.release(KEY_UP_ARROW);
                Step = 0; // Zurück zum Grundzustand.
            }
            break;

        case 22: // Langer Knopfdruck erkannt. Halte "Pfeil Hoch" gedrückt.
            Keyboard.press(KEY_UP_ARROW);
            if (!PlungerPressed) Step = 23; // Wenn losgelassen, gehe zum Aufräumen.
            break;

        case 23: // Knopf nach langem Druck losgelassen.
            z = JoyMin; // Stelle sicher, dass die Z-Achse auf 0 ist.
            Keyboard.release(KEY_UP_ARROW);
            Step = 0; // Zurück zum Grundzustand.
            break;

        // --- Zweig 2: Analoge Plunger-Aktion (Encoder wurde bewegt) ---
        case 40: // Encoder wird bewegt. Aktualisiere die Z-Achse.
            if (Position != PositionOld) {
                PlungerAktualisieren();
                PositionOld = Position;
            }
            if (PlungerPressed) Step = 41; // Wenn Knopf gedrückt wird, prüfe auf "Cancel" oder "Launch".
            break;

        case 41: // Knopf ist gedrückt, während Encoder aktiv ist.
            // Wenn lange gedrückt: "Cancel"-Aktion.
            if (millis() - PlungerPressStartTime > LongPlungerPressTime) Step = 45;
            // Wenn kurz gedrückt und losgelassen: "Launch"-Aktion.
            else if (!PlungerPressed) Step = 42; 
            break;

        case 42: // Loslassen
            Position = 0;
            Position = 0;
            PlungerAktualisieren();
            KnopfGedreht = false;
            Step = 0;
            break;

        case 45: // "Cancel"-Aktion: Fahre den Plunger langsam animiert zurück.
        {
            static int animation_start_pos = 0;
            if (case45_entry_time == 0) {
                case45_entry_time = millis();
                animation_start_pos = Position;
            }

            unsigned long elapsed_time = millis() - case45_entry_time;

            if (elapsed_time < PlungerCancelAnimationTime) {
                Position = map(elapsed_time, 0, PlungerCancelAnimationTime, animation_start_pos, 0);
                // Temporäres Setzen ohne den Encoder-Hardware-Zähler zu überschreiben, 
                // damit die Logik stimmt, aber hier setzen wir den z-Wert direkt.
                z = map(Position, 0, MaxPosition, JoyMin, JoyMax);
            } else {
                Position = 0;
                Position = 0;
                PlungerAktualisieren();
                KnopfGedreht = false;
                if (!PlungerPressed) {
                    case45_entry_time = 0;
                    Step = 0;
                }
            }
        }
        break;

        default:
            Step = 0;
            break;
    }

    // --- Status LED Logik ---
    // Prüfen, ob irgendein Button gedrückt ist.
    bool anyButtonPressed = false;
    // Die Logik hier berücksichtigt die unterschiedliche Verschaltung der Taster:
    // - Normally Closed (NC) Flipper: Der Kontakt ist im Ruhezustand geschlossen (LOW).
    //   Ein Druck öffnet den Kontakt -> Pin wird durch PULLUP auf HIGH gezogen. -> `read() == HIGH`
    // - Normally Open (NO) Taster: Der Kontakt ist im Ruhezustand offen (HIGH durch PULLUP).
    //   Ein Druck schließt den Kontakt -> Pin wird auf GND gezogen (LOW). -> `read() == LOW`
    if (buttonFL.read() == HIGH ||
        buttonFR.read() == HIGH ||
        buttonML.read() == LOW ||
        buttonMR.read() == LOW ||
        buttonCR.read() == LOW ||
        digitalRead(PIN_TILT) == LOW || // Direkte Abfrage des Pins für die LED
        buttonAU.read() == LOW ||
        buttonAD.read() == LOW ||
        buttonAL.read() == LOW ||
        buttonAR.read() == LOW ||
        buttonESC.read() == LOW ||
        buttonRET.read() == LOW ||
        buttonPLU.read() == LOW ||
        buttonNUM2.read() == LOW ||
        buttonNUM5.read() == LOW ||
        buttonNUM8.read() == LOW) {
        anyButtonPressed = true;
    }

    statusPixel.setPixelColor(0, anyButtonPressed ? statusPixel.Color(0, 0, 50) : 0);
    statusPixel.show();
}