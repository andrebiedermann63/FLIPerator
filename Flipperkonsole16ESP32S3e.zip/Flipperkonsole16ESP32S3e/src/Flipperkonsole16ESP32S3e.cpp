/*
Keyboard emulation works.
Neopixel LED works.
Plunger works.
Accelerator works.
SHIFT and CTRL keys now also work.
USB sending optimized to not unnecessarily load the USB interface.
Comments improved.
Periodically update USB to compensate for lost events.
Extend tilt pulse to the PC to 20ms.
Behavior of Numpad 2, 5, and 8 corrected.
TODO:
Test mit VPX

================================================================================
  Pinout ESP32-S3 Flipper Controller
================================================================================

  Function                 | Pin Name in Code | GPIO | Logic | Emulated Key
  -------------------------|------------------|------|-------|-------------------------
  ** I2C (for MPU6050 Gyro) **
  I2C Data                 | I2C_SDA          | 8    | -     | (Joystick X/Y-Achse)
  I2C Clock                | I2C_SCL          | 9    | -     | (Joystick X/Y-Achse)

  ** Flipper & Magna-Save **
  Right Flipper            | PIN_FR           | 1    | NC    | Right Shift Key
  Left Flipper             | PIN_FL           | 2    | NC    | Left Shift Key
  Right Magna-Save         | PIN_MR           | 4    | NO    | Right Ctrl Key
  Left Magna-Save          | PIN_ML           | 5    | NO    | Left Ctrl Key

  ** Game & System Keys **
  Credit / Coin            | PIN_CR           | 3    | NO    | '5'
  TILT                     | PIN_TILT         | 6    | NO    | 't'
  Start / Enter (Return)   | PIN_RET          | 14   | NO    | Enter / Return
  Escape                   | PIN_ESC          | 13   | NO    | Escape

  ** Menu Navigation **
  Arrow Up                 | PIN_AU           | 7    | NO    | Arrow Up
  Arrow Down               | PIN_AD           | 10   | NO    | Arrow Down
  Arrow Left               | PIN_AL           | 11   | NO    | Arrow Left
  Arrow Right              | PIN_AR           | 12   | NO    | Arrow Right

  ** Numpad Keys **
  Numpad 2                 | PIN_NUM2         | 16   | NO    | Numpad 2
  Numpad 5                 | PIN_NUM5         | 17   | NO    | Numpad 5
  Numpad 8                 | PIN_NUM8         | 18   | NO    | Numpad 8

  ** Plunger (Analog & Digital) **
  Plunger Encoder A        | ROT1             | 42   | -     | (Joystick Z-Achse)
  Plunger Encoder B        | ROT2             | 41   | -     | (Joystick Z-Achse)
  Plunger Button (Launch)  | PLU              | 21   | NO    | Arrow Up

  ** Miscellaneous **
  Onboard NeoPixel LED     | NEOPIXEL_PIN     | 48   | -     | (Status LED)

================================================================================
*/
#include <Arduino.h>
#include <Wire.h>
#include <Bounce2.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include "USB.h"
#include "USBHIDKeyboard.h"
#include "USBHIDGamepad.h"
#include "USBHID.h" // WICHTIG: Diesen Header für den 'KeyCode' Typ einbinden
#include <Adafruit_NeoPixel.h>

// Manual definitions for keypad keys.
// The default definitions in many libraries are for a US layout.
// These are the correct USB HID scancodes that should work layout-independently.
#define KEY_KP_2 0x5A // Numpad 2
#define KEY_KP_5 0x5D // Numpad 5
#define KEY_KP_8 0x60 // Numpad 8

// Manual definition of HID modifier bitmasks for the KeyReport.
// This is the more robust way to control modifier keys (SHIFT, CTRL, etc.).
#define KEY_MOD_LCTRL  0x01
#define KEY_MOD_LSHIFT 0x02
#define KEY_MOD_LALT   0x04
#define KEY_MOD_LGUI   0x08
#define KEY_MOD_RCTRL  0x10
#define KEY_MOD_RSHIFT 0x20
#define KEY_MOD_RALT   0x40
#define KEY_MOD_RGUI   0x80

/*
  LIBRARIES (install via Library Manager):
  1. Adafruit MPU6050
  2. Adafruit Unified Sensor
  3. Bounce2
*/

// Initialize USB HID objects
USBHIDKeyboard Keyboard;
USBHIDGamepad Gamepad;

// HID Report structure to hold the state of all modifier keys
KeyReport keyReport;

// NeoPixel object for the onboard LED
Adafruit_NeoPixel statusPixel(1, 48, NEO_GRB + NEO_KHZ800);

// PIN DEFINITIONS FOR ESP32-S3 (Please adapt to your specific board!)
// I2C Pins (Standard for many S3 boards, but check to be sure)
#define I2C_SDA 8
#define I2C_SCL 9

// Button Pins (Using GPIOs that are safe for Input Pullup)
#define PIN_FR    1   // Right Flipper
#define PIN_FL    2   // Left Flipper
#define PIN_CR    3   // Credits
#define PIN_MR    4   // Right Magna Save
#define PIN_ML    5   // Left Magna Save
#define PIN_TILT  6   // TILT
#define PIN_AU    7   // Arrow UP
#define PIN_AD    10  // Arrow DOWN
#define PIN_AL    11  // Arrow LEFT
#define PIN_AR    12  // Arrow RIGHT
#define PIN_ESC   13  // Pin Escape
#define PIN_RET   14  // Pin Return/Enter
// #define LED   15  // Old definition for external LED, replaced by NeoPixel
#define PIN_NUM2  16  // Pin Numpad 2
#define PIN_NUM5  17  // Pin Numpad 5
#define PIN_NUM8  18  // Pin Numpad 8

// Encoder & Plunger
#define ROT1  42  // Rotary Encoder A - IMPORTANT: Do not use GPIO 19/20 as they are reserved for USB!
#define ROT2  41  // Rotary Encoder B - IMPORTANT: Do not use GPIO 19/20 as they are reserved for USB!
#define PLU   21  // Plunger-Button (Pin with internal Pull-Up)

// Constant declarations
const int ButtonDebounce = 5;      // Debounce time (ms)
const int TILT_PULSE_DURATION_MS = 20; // Minimum duration for the TILT keypress
const int NUM5_PULSE_DURATION_MS = 20; // Duration for the Numpad-5 keypress

const int MaxPosition = 300;       // Maximum logical encoder position
const int StartPosition = 240;     // Start position for plunger logic
const int ReleasePosition = 50;    // Release threshold

// Joystick value range for ESP32 HID Gamepad is typically -127 to 127 (int8_t)
const int JoyMin = -127;
const int JoyMax = 127;
// Adjust MPU sensitivity for the new range
const int AccelleromerterSensivity = 8; 

const int TiltFilterTime = 1000;
const unsigned long ShortPlungerPressTime = 300;
const unsigned long LongPlungerPressTime = 1000;
const int PlungerMaxHoldTime = 1000;
const unsigned long PlungerCancelAnimationTime = 500;

// Repeating key constants
const int REPEAT_INITIAL_DELAY_MS = 300;
const int REPEAT_PRESS_DURATION_MS = 30;
const int REPEAT_RELEASE_DURATION_MS = 30;

// Structure for managing keys with repeat function
// The `RepeatingKey` structure is no longer used, the logic is now implemented directly in `handleButtons`.
// struct RepeatingKey {
//   ...
// };

// Objects
Adafruit_MPU6050 mpu;

// Button objects
Bounce buttonFR = Bounce();
Bounce buttonFL = Bounce();
Bounce buttonMR = Bounce();
Bounce buttonML = Bounce();
Bounce buttonCR = Bounce();
Bounce buttonTILT = Bounce();
Bounce buttonAU = Bounce();
Bounce buttonAD = Bounce();
Bounce buttonAL = Bounce();
Bounce buttonAR = Bounce();
Bounce buttonESC = Bounce();
Bounce buttonRET = Bounce();
Bounce buttonPLU = Bounce();
Bounce buttonNUM2 = Bounce();
Bounce buttonNUM5 = Bounce();
Bounce buttonNUM8 = Bounce();

// Variables for manual encoder polling
// For robust quadrature decoding
volatile int8_t encoder_last_state = 0;
// Lookup table for the state transitions of the encoder.
// Index: (last_state << 2) | current_state
// Values: 0 = no change, 1 = CW, -1 = CCW
const int8_t encoder_states[] = {0,-1,1,0,1,0,0,-1,-1,0,0,1,0,1,-1,0};



// Variables
unsigned long TiltMillis;               // Timestamp to debounce/filter TILT inputs
int Position = 0;                       // Current logical position of the plunger encoder (0 to MaxPosition)
int PositionOld = 0;                    // Last known position of the encoder to detect changes
bool KnopfGedreht = false;              // Flag indicating if the plunger (encoder) has been moved and the logic is active
int PositionOut;                        // Mapped encoder value for the joystick Z-axis (-127 to 127)
uint8_t lastModifiers = 0;              // State of the modifier keys from the last report to avoid unnecessary sends
unsigned long PlungerPressStartTime = 0;  // Timestamp of when the plunger button was pressed
bool PlungerPressed = false;            // Current state of the plunger button (pressed/released) 
int tiltState = 0;                      // State for the non-blocking TILT logic (0=idle, 1=pressed, 2=waiting_release)
float xbaseline, ybaseline;             // Zero-point offset for the accelerometer after calibration
int num2State = 0;                      // State for the non-blocking Numpad-2 logic
unsigned long num2_press_timer = 0;     // Timer for the duration of the Numpad-2 keypress
int num5State = 0;                      // State for the non-blocking Numpad-5 logic
unsigned long num5_press_timer = 0;     // Timer for the duration of the Numpad-5 keypress
int num8State = 0;                      // State for the non-blocking Numpad-8 logic
unsigned long num8_press_timer = 0;     // Timer for the duration of the Numpad-8 keypress
volatile bool tiltInterruptFired = false; // Flag set by the TILT interrupt routine
bool tiltKeyPressed = false;            // State for the TILT key to prevent orphaned 'release' commands
sensors_event_t accel, gyro, temp;      // Structs to store MPU6050 sensor data
int x, y;                               // Processed values for the joystick X and Y axes (Nudge/Tilt)
int z;                                  // Processed value for the joystick Z-axis (Plunger)
int Step = 0;                           // Current step in the plunger state machine
unsigned long step_timer = 0;           // Universal timer for non-blocking delays in the state machine
unsigned long tilt_press_timer = 0;     // Timer for the duration of the TILT keypress
unsigned long case45_entry_time = 0;    // Special timer for the start of the "Cancel" animation (Step 45)

// Timer to limit the gamepad sending frequency
unsigned long last_gamepad_send_time = 0;
const int GAMEPAD_SEND_INTERVAL_MS = 10; // Send every 10ms (100Hz). A good compromise between latency and USB load.

void readEncoder() {
    // Robust quadrature decoding (corrected version)
    
    // 1. Read the current state of the two pins (results in a value from 0-3)
    int8_t current_state = (digitalRead(ROT1) << 1) | digitalRead(ROT2);

    // 2. Combine the old and new state to create an index for the lookup table
    int8_t lookup_index = (encoder_last_state << 2) | current_state;

    // 3. Increment/decrement the position based on the value from the table
    Position += encoder_states[lookup_index];

    // 4. Store the current state for the next iteration
    encoder_last_state = current_state;
}

// Interrupt Service Routine (ISR) for the TILT pin.
// This function is called IMMEDIATELY when the pin goes LOW.
// IRAM_ATTR ensures the code is in fast IRAM.
void IRAM_ATTR onTilt() {
    tiltInterruptFired = true;
}

void setup() {
    // USB initialization for ESP32-S3
    // MUST be done before Serial.begin() if USB-CDC is active!
    USB.begin();
    Keyboard.begin();
    Gamepad.begin();
    
    // Serial.begin(115200); // Completely disable serial output for testing to avoid USB conflicts

    // I2C initialization
    Wire.begin(I2C_SDA, I2C_SCL);

    // MPU6050
    if (!mpu.begin()) {
        // Serial.println("MPU6050 not found! Check wiring.");
        // while (1) delay(10); // Removed endless loop so controller still boots
    } else {
        // Serial.println("MPU6050 found");
        mpu.setAccelerometerRange(MPU6050_RANGE_2_G);
        mpu.setFilterBandwidth(MPU6050_BAND_94_HZ);
        
        // Calibration
        for (int i = 0; i < 100; i++) {
            mpu.getEvent(&accel, &gyro, &temp);
            xbaseline += accel.acceleration.x;
            ybaseline += accel.acceleration.y;
            delay(5); // Short pause between measurements
            delay(0); // Feed the watchdog to prevent a boot loop
        }
        xbaseline /= 100;
        ybaseline /= 100;
    }

    // Pins Attach
    buttonFL.attach(PIN_FL, INPUT_PULLUP); buttonFL.interval(ButtonDebounce);
    buttonFR.attach(PIN_FR, INPUT_PULLUP); buttonFR.interval(ButtonDebounce);
    buttonML.attach(PIN_ML, INPUT_PULLUP); buttonML.interval(ButtonDebounce);
    buttonMR.attach(PIN_MR, INPUT_PULLUP); buttonMR.interval(ButtonDebounce);    
    buttonCR.attach(PIN_CR, INPUT_PULLUP); buttonCR.interval(ButtonDebounce);
    buttonAU.attach(PIN_AU, INPUT_PULLUP); buttonAU.interval(ButtonDebounce);
    buttonAD.attach(PIN_AD, INPUT_PULLUP); buttonAD.interval(ButtonDebounce);
    buttonAL.attach(PIN_AL, INPUT_PULLUP); buttonAL.interval(ButtonDebounce);
    buttonAR.attach(PIN_AR, INPUT_PULLUP); buttonAR.interval(ButtonDebounce);
    buttonESC.attach(PIN_ESC, INPUT_PULLUP); buttonESC.interval(ButtonDebounce);
    buttonRET.attach(PIN_RET, INPUT_PULLUP); buttonRET.interval(ButtonDebounce);
    buttonPLU.attach(PLU, INPUT_PULLUP); buttonPLU.interval(ButtonDebounce);
    buttonNUM2.attach(PIN_NUM2, INPUT_PULLUP); buttonNUM2.interval(ButtonDebounce);
    buttonNUM5.attach(PIN_NUM5, INPUT_PULLUP); buttonNUM5.interval(ButtonDebounce);
    buttonNUM8.attach(PIN_NUM8, INPUT_PULLUP); buttonNUM8.interval(ButtonDebounce);

    // Configure TILT pin separately as an interrupt to catch even the shortest pulses.
    pinMode(PIN_TILT, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(PIN_TILT), onTilt, FALLING);

    // Initialize onboard NeoPixel LED and set to red
    statusPixel.begin(); // Just initialize, don't turn on
    
    // Configure encoder pins for manual polling
    pinMode(ROT1, INPUT_PULLUP);
    pinMode(ROT2, INPUT_PULLUP);
    // Read the initial state of the encoder
    encoder_last_state = (digitalRead(ROT1) << 1) | digitalRead(ROT2);

    TiltMillis = millis() + TiltFilterTime;
}

void PlungerAktualisieren() {
    // The 'Position' value is now updated by readEncoder().
    
    // Logical clamping
    if (Position > MaxPosition) {
        Position = MaxPosition;
    } else if (Position < 0) {
        Position = 0;
    }

    // Mapping: 0 to MaxPosition (300) -> HID range -127 to 127
    // For Z-axis in Visual Pinball
    PositionOut = map(Position, 0, MaxPosition, JoyMin, JoyMax);
    z = PositionOut; // Store Z-axis value in global variable
}

void handleButtons() {
    // Button updates
    buttonFL.update(); buttonFR.update(); buttonML.update(); buttonMR.update();
    buttonCR.update(); buttonAU.update(); buttonAD.update();
    buttonAL.update(); buttonAR.update(); buttonESC.update(); buttonRET.update();
    buttonPLU.update(); buttonNUM2.update(); buttonNUM5.update(); buttonNUM8.update();

    // --- Logik für Tasten (Identisch zum Teensy Code, angepasst für ESP32 Libs) ---
    
    // Shift keys (Flippers) - using KeyReport for reliable function
    // These buttons are "Normally Closed" (NC), so the logic is inverted: rose() = pressed, fell() = released.
    if (buttonFL.rose())  keyReport.modifiers |= KEY_MOD_LSHIFT;  // Button pressed (contact opens -> LOW to HIGH)
    if (buttonFL.fell())  keyReport.modifiers &= ~KEY_MOD_LSHIFT; // Button released (contact closes -> HIGH to LOW)
    
    if (buttonFR.rose())  keyReport.modifiers |= KEY_MOD_RSHIFT;  // Button pressed
    if (buttonFR.fell())  keyReport.modifiers &= ~KEY_MOD_RSHIFT; // Button released

    // Magna Save (CTRL) - using KeyReport for reliable function
    if (buttonML.fell())  keyReport.modifiers |= KEY_MOD_LCTRL;
    if (buttonML.rose())  keyReport.modifiers &= ~KEY_MOD_LCTRL;

    if (buttonMR.fell())  keyReport.modifiers |= KEY_MOD_RCTRL;
    if (buttonMR.rose())  keyReport.modifiers &= ~KEY_MOD_RCTRL;

    // Arrow keys
    if (buttonAU.fell())  Keyboard.press(KEY_UP_ARROW);
    if (buttonAU.rose())  Keyboard.release(KEY_UP_ARROW);
    
    if (buttonAD.fell()) Keyboard.press(KEY_DOWN_ARROW);
    if (buttonAD.rose())  Keyboard.release(KEY_DOWN_ARROW);

    if (buttonAL.fell()) Keyboard.press(KEY_LEFT_ARROW);
    if (buttonAL.rose())  Keyboard.release(KEY_LEFT_ARROW);

    if (buttonAR.fell()) Keyboard.press(KEY_RIGHT_ARROW);
    if (buttonAR.rose())  Keyboard.release(KEY_RIGHT_ARROW);

    // System keys
    if (buttonESC.fell()) Keyboard.press(KEY_ESC);
    if (buttonESC.rose())  Keyboard.release(KEY_ESC);

    if (buttonRET.fell()) Keyboard.press(KEY_RETURN);
    if (buttonRET.rose())  Keyboard.release(KEY_RETURN);

    // Coin (sends the character '5')
    // Send only a single keypress when the button is pressed.
    // Keyboard.write() sends a press() followed by a release() and thus prevents repetition by the OS.
    if (buttonCR.fell()) {
        Keyboard.write('5');
    }

    // Numpad 2: Non-blocking pulse logic with repetition
    switch (num2State) {
        case 0: // IDLE
            if (buttonNUM2.fell()) {
                Keyboard.pressRaw(KEY_KP_2);
                num2_press_timer = millis();
                num2State = 1; // Send first pulse
            }
            break;
        case 1: // FIRST_PULSE_RELEASE: Wait to end the first pulse
            if (millis() - num2_press_timer >= REPEAT_RELEASE_DURATION_MS) {
                Keyboard.releaseRaw(KEY_KP_2);
                num2_press_timer = millis();
                num2State = 2; // Go to the waiting phase for repetition
            }
            break;
        case 2: // WAITING_FOR_REPEAT: Wait for release or start of repetition
            if (buttonNUM2.rose()) {
                num2State = 0;
            } else if (millis() - num2_press_timer >= REPEAT_INITIAL_DELAY_MS) {
                num2_press_timer = millis();
                num2State = 3; // Start the repetition sequence
            }
            break;
        case 3: // REPEATING_PRESS: Send a repeat pulse
            if (buttonNUM2.rose()) { // Also check for release here
                num2State = 0;
            } else {
                Keyboard.pressRaw(KEY_KP_2);
                num2_press_timer = millis();
                num2State = 4;
            }
            break;
        case 4: // REPEATING_RELEASE: End the repeat pulse
            if (buttonNUM2.rose()) { // Also check for release here
                Keyboard.releaseRaw(KEY_KP_2); // Ensure the key is released
                num2State = 0;
            } else if (millis() - num2_press_timer >= REPEAT_RELEASE_DURATION_MS) {
                Keyboard.releaseRaw(KEY_KP_2);
                num2_press_timer = millis();
                num2State = 3; // Back to the next repeat press (after a short pause)
            }
            break;
    }

    // Numpad 5: Non-blocking pulse logic for a single, clean keypress.
    // We use pressRaw() and releaseRaw() to bypass the layout problem.
    switch (num5State) {
        case 0: // IDLE: Wait for keypress
            if (buttonNUM5.fell()) {
                Keyboard.pressRaw(KEY_KP_5);
                num5_press_timer = millis(); // Start timer
                num5State = 1; // Switch to the next state
            }
            break;
        case 1: // PRESSED: Wait until the pulse duration has elapsed
            if (millis() - num5_press_timer >= NUM5_PULSE_DURATION_MS) {
                Keyboard.releaseRaw(KEY_KP_5);
                num5State = 2; // Go into a waiting state until the key is released
            }
            break;
        case 2: // WAITING_RELEASE: Do nothing until the key is physically released
            if (buttonNUM5.rose()) {
                num5State = 0; // Ready for the next press
            }
            break;
    }

    // Numpad 8: Non-blocking pulse logic with repetition
    switch (num8State) {
        case 0: // IDLE
            if (buttonNUM8.fell()) {
                Keyboard.pressRaw(KEY_KP_8);
                num8_press_timer = millis();
                num8State = 1; // Send first pulse
            }
            break;
        case 1: // FIRST_PULSE_RELEASE: Wait to end the first pulse
            if (millis() - num8_press_timer >= REPEAT_RELEASE_DURATION_MS) {
                Keyboard.releaseRaw(KEY_KP_8);
                num8_press_timer = millis();
                num8State = 2; // Go to the waiting phase for repetition
            }
            break;
        case 2: // WAITING_FOR_REPEAT: Wait for release or start of repetition
            if (buttonNUM8.rose()) {
                num8State = 0;
            } else if (millis() - num8_press_timer >= REPEAT_INITIAL_DELAY_MS) {
                num8_press_timer = millis(); // Start the repetition sequence
                num8State = 3;
            }
            break;
        case 3: // REPEATING_PRESS: Send a repeat pulse
            if (buttonNUM8.rose()) { // Also check for release here
                num8State = 0;
            } else {
                Keyboard.pressRaw(KEY_KP_8);
                num8_press_timer = millis();
                num8State = 4;
            }
            break;
        case 4: // REPEATING_RELEASE: End the repeat pulse
            if (buttonNUM8.rose()) { // Also check for release here
                Keyboard.releaseRaw(KEY_KP_8); // Ensure the key is released
                num8State = 0;
            } else if (millis() - num8_press_timer >= REPEAT_RELEASE_DURATION_MS) {
                Keyboard.releaseRaw(KEY_KP_8);
                num8_press_timer = millis();
                num8State = 3; // Back to the next repeat press (after a short pause)
            }
            break;
    }

    // The keyboard report for the modifier keys is now sent together with the gamepad data
    // at a fixed interval in the main loop() to increase robustness.
    // This prevents a "release" command from being lost and the key from "sticking".
    // We only check here if something has changed to send the report.
}

void loop() {
    // Read encoder via polling
    readEncoder();

    // --- Non-blocking TILT logic (based on interrupt) ---
    switch (tiltState) {
        case 0: // IDLE: Wait for a TILT pulse
            if (tiltInterruptFired) {
                tiltInterruptFired = false; // Reset flag
                // Check if the filter time has elapsed before triggering a new TILT.
                if (millis() > TiltMillis) {
                    Keyboard.press('t');
                    tilt_press_timer = millis(); // Start timer for pulse duration
                    tiltState = 1; // Go to the next state
                }
            }
            break;

        case 1: // PRESSED: Wait until the pulse duration (20ms) has elapsed.
            if (millis() - tilt_press_timer >= TILT_PULSE_DURATION_MS) {
                Keyboard.release('t');
                TiltMillis = millis() + TiltFilterTime; // Start block time for the next TILT
                tiltState = 0; // Back to idle state
            }
            break;

        default:
            tiltState = 0; // Catch invalid states
            break;
    }

    mpu.getEvent(&accel, &gyro, &temp);

    // MPU Mapping: Acceleration to Joystick X/Y
    // Teensy 0-1023 -> ESP32 -127 to 127
    int x_raw = map((long)((accel.acceleration.x - xbaseline) * 100), 
                    -AccelleromerterSensivity * 100, 
                    AccelleromerterSensivity * 100, 
                    JoyMin, JoyMax);
                    
    int y_raw = map((long)((accel.acceleration.y - ybaseline) * 100), 
                    -AccelleromerterSensivity * 100, 
                    AccelleromerterSensivity * 100, 
                    JoyMax, JoyMin); // Inverted as in the original

    // Constrain to prevent overflow
    x = constrain(x_raw, JoyMin, JoyMax);
    y = constrain(y_raw, JoyMin, JoyMax);

    // Send gamepad and keyboard modifier data at a fixed interval.
    // This ensures that the host regularly receives the correct state,
    // even if a previous packet was lost.
    if (millis() - last_gamepad_send_time >= GAMEPAD_SEND_INTERVAL_MS) {
        Gamepad.send(x, y, z, 0, 0, 0, 0, 0); // x, y, z, rz, rx, ry, hat, buttons
        last_gamepad_send_time = millis();
        if (keyReport.modifiers != lastModifiers) {
            Keyboard.sendReport(&keyReport);
            lastModifiers = keyReport.modifiers;
        }
    }

    // Execute button logic
    handleButtons();

    // --- Plunger Logic & State Machine ---
    // Position is already updated at the beginning of the loop() by readEncoder().
    if (Position > MaxPosition) { Position = MaxPosition; }
    else if (Position < 0) { Position = 0; }

    if (buttonPLU.fell()) {
        PlungerPressed = true;
        PlungerPressStartTime = millis();
    }
    if (buttonPLU.rose()) {
        PlungerPressed = false;
    }

    switch (Step) {
        // ====================================================================================
        // Plunger State Machine
        // ====================================================================================
        case 0: // IDLE / Base state: Waiting for an action.
            if ((Position >= 1) && !KnopfGedreht) { // EncoderMin simplified to 1 here
                Position = StartPosition;
                Position = StartPosition;
                PlungerAktualisieren();
                KnopfGedreht = true; // Remember that the encoder logic is now active.
            }
            if (PlungerPressed) Step = 20;  // If the button is pressed -> Go to button logic
            if (KnopfGedreht) Step = 40;     // If the encoder has been moved -> Go to encoder logic
            break;

        // --- Branch 1: Digital plunger action (button pressed without encoder movement) ---
        case 20: // Button was pressed. Send "Arrow Up" for the digital launch.
            Keyboard.press(KEY_UP_ARROW); // Launch Ball
            if (!PlungerPressed) {
                // Button has already been released. Differentiate between short and long press.
                if (millis() - PlungerPressStartTime < ShortPlungerPressTime) Step = 21;
                else Step = 22;
            }
            break;

        case 21: // Short button press detected. Simulate a full analog plunger pull.
            z = JoyMax; // Set Z-axis to maximum.
            step_timer = millis();
            Step = 211; // Go to the waiting state.
            break;

        case 211: // Wait a defined time before the simulated plunger snaps back.
            if (millis() - step_timer >= PlungerMaxHoldTime) {
                z = JoyMin; // Reset Z-axis to minimum.
                Keyboard.release(KEY_UP_ARROW);
                Step = 0; // Back to base state.
            }
            break;

        case 22: // Long button press detected. Hold "Arrow Up".
            Keyboard.press(KEY_UP_ARROW);
            if (!PlungerPressed) Step = 23; // If released, go to cleanup.
            break;

        case 23: // Button released after long press.
            z = JoyMin; // Ensure Z-axis is at 0.
            Keyboard.release(KEY_UP_ARROW);
            Step = 0; // Back to base state.
            break;

        // --- Branch 2: Analog plunger action (encoder has been moved) ---
        case 40: // Encoder is being moved. Update the Z-axis.
            if (Position != PositionOld) {
                PlungerAktualisieren();
                PositionOld = Position;
            }
            if (PlungerPressed) Step = 41; // If button is pressed, check for "Cancel" or "Launch".
            break;

        case 41: // Button is pressed while encoder is active.
            // If held for a long time: "Cancel" action.
            if (millis() - PlungerPressStartTime > LongPlungerPressTime) Step = 45;
            // If pressed briefly and released: "Launch" action.
            else if (!PlungerPressed) Step = 42; 
            break;

        case 42: // Loslassen
            Position = 0;
            Position = 0;
            PlungerAktualisieren();
            KnopfGedreht = false;
            Step = 0;
            break;

        case 45: // "Cancel" action: Animate the plunger back slowly.
        {
            static int animation_start_pos = 0;
            if (case45_entry_time == 0) {
                case45_entry_time = millis();
                animation_start_pos = Position;
            }

            unsigned long elapsed_time = millis() - case45_entry_time;

            if (elapsed_time < PlungerCancelAnimationTime) {
                Position = map(elapsed_time, 0, PlungerCancelAnimationTime, animation_start_pos, 0);
                // Temporary setting without overwriting the encoder hardware counter,
                // so the logic is correct, but here we set the z-value directly.
                z = map(Position, 0, MaxPosition, JoyMin, JoyMax);
            } else {
                Position = 0;
                Position = 0;
                PlungerAktualisieren();
                KnopfGedreht = false;
                if (!PlungerPressed) {
                    case45_entry_time = 0;
                    Step = 0;
                }
            }
        }
        break;

        default:
            Step = 0;
            break;
    }

    // --- Status LED Logic ---
    // Check if any button is pressed.
    bool anyButtonPressed = false;
    // The logic here takes into account the different wiring of the buttons:
    // - Normally Closed (NC) Flipper: The contact is closed at rest (LOW).
    //   A press opens the contact -> Pin is pulled HIGH by PULLUP. -> `read() == HIGH`
    // - Normally Open (NO) button: The contact is open at rest (HIGH due to PULLUP).
    //   A press closes the contact -> Pin is pulled to GND (LOW). -> `read() == LOW`
    if (buttonFL.read() == HIGH ||
        buttonFR.read() == HIGH ||
        buttonML.read() == LOW ||
        buttonMR.read() == LOW ||
        buttonCR.read() == LOW ||
        digitalRead(PIN_TILT) == LOW || // Direct query of the pin for the LED
        buttonAU.read() == LOW ||
        buttonAD.read() == LOW ||
        buttonAL.read() == LOW ||
        buttonAR.read() == LOW ||
        buttonESC.read() == LOW ||
        buttonRET.read() == LOW ||
        buttonPLU.read() == LOW ||
        buttonNUM2.read() == LOW ||
        buttonNUM5.read() == LOW ||
        buttonNUM8.read() == LOW) {
        anyButtonPressed = true;
    }

    statusPixel.setPixelColor(0, anyButtonPressed ? statusPixel.Color(0, 0, 50) : 0);
    statusPixel.show();
}